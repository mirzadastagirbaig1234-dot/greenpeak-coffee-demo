import { FormEvent, useEffect, useState } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  Box,
  Check,
  Coffee,
  Handshake,
  Leaf,
  Mail,
  Menu,
  Mountain,
  PackageCheck,
  Phone,
  Send,
  MessageCircle,
  Sprout,
  X,
} from 'lucide-react';

const WHATSAPP_URL = 'https://wa.me/918310595329?text=Hi%20GreenPeak%20Coffee%2C%20I%20would%20like%20to%20enquire%20about%20your%20Robusta%20Blend.';

function Logo({ light = false }: { light?: boolean }) {
  return (
    <a className={`brand-logo ${light ? 'brand-logo--light' : ''}`} href="#home" aria-label="GreenPeak Coffee home">
      <svg className="brand-mark" viewBox="0 0 70 52" aria-hidden="true">
        <path d="M7 42 27 15l9 11 9-13 18 29H7Z" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinejoin="round" />
        <path d="M15 42h39M46 12c6 1 10 5 11 11-6 0-10-4-11-11Z" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" />
        <path d="M49 22c-3 4-6 7-10 9" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      </svg>
      <span className="brand-wordmark">GreenPeak<small>COFFEE</small></span>
    </a>
  );
}

const navItems = [
  ['Home', '#home'],
  ['Our Robusta', '#blend'],
  ['Why GreenPeak', '#why'],
  ['Product Details', '#details'],
  ['Contact', '#contact'],
];

const features = [
  { icon: Mountain, label: '100% Robusta', detail: 'Chikmagalur Origin' },
  { icon: Handshake, label: 'Ethically Sourced', detail: 'From trusted growers' },
  { icon: Box, label: 'Eco-Friendly', detail: 'Thoughtful packaging' },
  { icon: Coffee, label: 'Bold & Aromatic', detail: 'A cup with character' },
];

const reasons = [
  { icon: Sprout, title: 'Premium Robusta Beans', text: 'Strong, full-bodied beans selected for a beautifully rounded cup.' },
  { icon: Mountain, title: 'Sourced from Chikmagalur', text: 'Grown in one of India’s most storied coffee landscapes.' },
  { icon: PackageCheck, title: 'Eco-Friendly Packaging', text: 'Designed with a lighter footprint and a longer shelf life.' },
  { icon: Coffee, title: 'Rich, Long-Lasting Taste', text: 'A bold finish that stays with you, cup after cup.' },
];

const packagingCards = [
  { title: 'Premium Logo & Clean Typography', text: 'A considered identity that feels as good as the coffee tastes.', className: 'packaging-card--wide' },
  { title: 'Eco-Friendly Packaging', text: 'Kraft paper, deep green, and a more thoughtful daily ritual.', className: '' },
  { title: 'Nature-Inspired Illustrations', text: 'A quiet nod to the hills, leaves, and people behind each bean.', className: '' },
  { title: 'Resealable Zipper for Freshness', text: 'Keep the aroma in and the outside world out.', className: '' },
  { title: 'Easy Brewing Guide', text: 'Simple enough for every morning, precise enough for every palate.', className: '' },
];

function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`reveal ${className}`}>{children}</div>;
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add('is-visible');
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
    return () => {
      window.removeEventListener('scroll', onScroll);
      observer.disconnect();
    };
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setFormError('');
    const form = event.currentTarget;
    const data = new FormData(form);
    const accessKey = import.meta.env.VITE_WEB3FORMS_ACCESS_KEY ?? 'YOUR_WEB3FORMS_ACCESS_KEY';
    data.append('access_key', accessKey);
    data.append('subject', 'New GreenPeak Coffee enquiry');
    data.append('from_name', 'GreenPeak Coffee website');
    data.append('botcheck', '');

    if (accessKey === 'YOUR_WEB3FORMS_ACCESS_KEY') {
      setFormError('The enquiry form is ready, but it still needs its Web3Forms access key to send messages.');
      setSubmitting(false);
      return;
    }

    try {
      const response = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: data });
      const result = await response.json() as { success?: boolean };
      if (!response.ok || !result.success) throw new Error('Unable to send');
      form.reset();
      setSubmitted(true);
    } catch {
      setFormError('Something went wrong while sending your enquiry. Please try WhatsApp instead.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="site-shell">
      <header className={`site-header ${scrolled ? 'site-header--scrolled' : ''}`}>
        <div className="container header-inner">
          <Logo light={!scrolled} />
          <nav className={`main-nav ${menuOpen ? 'main-nav--open' : ''}`} aria-label="Main navigation">
            {navItems.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}</a>)}
            <a className="button button--gold nav-cta" href={WHATSAPP_URL} target="_blank" rel="noreferrer">Enquire Now <ArrowUpRight size={15} /></a>
          </nav>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="hero-image" />
          <div className="hero-overlay" />
          <div className="container hero-content">
            <Reveal className="hero-copy">
              <p className="eyebrow eyebrow--light"><span /> From the hills of Chikmagalur</p>
              <h1>GreenPeak<br /><em>Robusta Blend</em></h1>
              <p className="hero-subtitle">Strong Aroma. Rich Taste. Real Coffee.</p>
              <p className="hero-description">A bold, beautifully honest Robusta for mornings that matter and moments worth lingering over.</p>
              <div className="hero-actions">
                <a className="button button--cream" href="#blend">Explore the Blend <ArrowDownRight size={16} /></a>
                <a className="text-link text-link--light" href={WHATSAPP_URL} target="_blank" rel="noreferrer">Enquire Now <ArrowUpRight size={15} /></a>
              </div>
            </Reveal>
            <Reveal className="hero-product">
              <div className="product-glow" />
              <img src="/greenpeak-bags.webp" alt="GreenPeak Coffee kraft and deep green Robusta coffee bags" />
              <p className="product-caption"><span /> Two expressions. One unmistakable strength.</p>
            </Reveal>
          </div>
          <a href="#features" className="scroll-cue" aria-label="Scroll to discover"><span>Scroll to discover</span><ArrowDownRight size={17} /></a>
        </section>

        <section id="features" className="feature-strip">
          <div className="container feature-grid">
            {features.map(({ icon: Icon, label, detail }) => <Reveal className="feature-item" key={label}><Icon size={25} strokeWidth={1.25} /><div><strong>{label}</strong><span>{detail}</span></div></Reveal>)}
          </div>
        </section>

        <section id="blend" className="section section--paper blend-section">
          <div className="container split-layout">
            <Reveal className="image-frame image-frame--bowl"><img src="/greenpeak-bowl.webp" alt="Roasted Robusta coffee beans in a ceramic bowl" /><span className="image-stamp">Chikmagalur<br />14° 08′ N</span></Reveal>
            <Reveal className="story-copy">
              <p className="eyebrow"><span /> Our story / the blend</p>
              <h2>Born in the mist.<br /><em>Made for the bold.</em></h2>
              <p>GreenPeak Robusta Blend brings you the bold and authentic taste of premium Robusta beans, carefully sourced from the lush coffee plantations of Chikmagalur. Crafted for those who love a strong, rich and aromatic cup.</p>
              <blockquote>“Not just coffee.<br /><em>It’s an experience.</em>”</blockquote>
              <a className="text-link" href="#why">Why GreenPeak <ArrowUpRight size={15} /></a>
            </Reveal>
          </div>
        </section>

        <section id="why" className="section section--forest why-section">
          <div className="leaf-detail leaf-detail--one"><Leaf size={160} strokeWidth={0.5} /></div>
          <div className="leaf-detail leaf-detail--two"><Leaf size={110} strokeWidth={0.5} /></div>
          <div className="container">
            <Reveal className="section-heading section-heading--light"><p className="eyebrow eyebrow--light"><span /> Why GreenPeak</p><h2>Good coffee has<br /><em>a point of view.</em></h2><p>From the first bean to the last sip, we keep things honest, intentional, and full of character.</p></Reveal>
            <div className="reason-grid">{reasons.map(({ icon: Icon, title, text }, index) => <Reveal className="reason-item" key={title}><div className="reason-number">0{index + 1}</div><Icon className="reason-icon" size={28} strokeWidth={1.1} /><h3>{title}</h3><p>{text}</p></Reveal>)}</div>
          </div>
        </section>

        <section id="packaging" className="section section--paper packaging-section">
          <div className="container">
            <Reveal className="section-heading section-heading--center"><p className="eyebrow"><span /> Details that matter</p><h2>A bag that feels<br /><em>like the place it comes from.</em></h2><p>Every detail is a quiet reflection of the hills, the harvest, and the hands behind the blend.</p></Reveal>
            <Reveal className="packaging-hero"><img src="/greenpeak-bags.webp" alt="GreenPeak Coffee packaging in kraft paper and forest green" /><div className="packaging-note"><span>01 / 05</span><strong>Our signature<br />packaging</strong><p>Designed to protect the aroma, and leave a lighter footprint.</p></div></Reveal>
            <div className="packaging-grid">{packagingCards.map((card, index) => <Reveal className={`packaging-card ${card.className}`} key={card.title}><span className="card-index">0{index + 1}</span><h3>{card.title}</h3><p>{card.text}</p><ArrowUpRight size={17} /></Reveal>)}</div>
          </div>
        </section>

        <section id="details" className="section details-section">
          <div className="container details-layout">
            <Reveal><p className="eyebrow"><span /> The essentials</p><h2>Everything you need<br /><em>to know.</em></h2><p className="details-intro">A confident cup, made uncomplicated. Keep it classic or make it your own.</p><div className="detail-table">{[['Blend', 'Robusta (Pure)'], ['Origin', 'Chikmagalur'], ['Roast Level', 'Medium Dark'], ['Taste Profile', 'Strong  |  Bold'], ['Available Sizes', '250g  /  500g  /  1kg']].map(([label, value]) => <div className="detail-row" key={label}><span>{label}</span><strong>{value}</strong></div>)}</div></Reveal>
            <Reveal className="brew-card"><div className="brew-card-top"><Coffee size={29} strokeWidth={1.1} /><span>Simple brewing guide</span></div><h3>Your perfect cup<br /><em>in three steps.</em></h3><div className="brew-steps"><div><b>01</b><span>Use<br /><strong>2 tsp / 10g</strong></span></div><div><b>02</b><span>Pour hot water<br /><strong>90–95°C</strong></span></div><div><b>03</b><span>Brew, breathe<br /><strong>and enjoy</strong></span></div></div><div className="brew-line" /></Reveal>
          </div>
        </section>

        <section id="contact" className="section section--forest contact-section">
          <div className="container contact-layout">
            <Reveal className="contact-copy"><p className="eyebrow eyebrow--light"><span /> Come say hello</p><h2>Let’s make your<br /><em>next cup count.</em></h2><p>Whether you’re discovering Robusta or stocking your shelves, we’d love to hear from you.</p><div className="contact-list"><a href="tel:+918310595329"><Phone size={18} /> +91 83105 95329</a><a href="mailto:zayaanurrahman92@gmail.com"><Mail size={18} /> zayaanurrahman92@gmail.com</a><span><Mountain size={18} /> Chikmagalur, India</span></div><a className="whatsapp-link" href={WHATSAPP_URL} target="_blank" rel="noreferrer"><MessageCircle size={17} /> Chat on WhatsApp <ArrowUpRight size={15} /></a></Reveal>
            <Reveal className="contact-card"><div className="form-heading"><span>ENQUIRE WITH US</span><p>Tell us a little about what<br />you’re looking for.</p></div>{submitted ? <div className="success-state"><div className="success-icon"><Check size={26} /></div><h3>Thank you!</h3><p>We’ll get back to you shortly.</p><button className="text-link" onClick={() => setSubmitted(false)}>Send another enquiry <ArrowUpRight size={15} /></button></div> : <form onSubmit={handleSubmit}><input type="checkbox" name="botcheck" className="botcheck" tabIndex={-1} autoComplete="off" /><div className="form-row"><label>Full Name<input name="name" required placeholder="Your name" /></label><label>Email<input name="email" type="email" required placeholder="you@example.com" /></label></div><div className="form-row"><label>Phone Number<input name="phone" type="tel" required placeholder="+91" /></label><label>Pack Size of Interest<select name="pack_size" defaultValue=""><option value="" disabled>Select a size</option><option>250g</option><option>500g</option><option>1kg</option><option>Bulk / Wholesale</option></select></label></div><label>Message<textarea name="message" required placeholder="How can we help?" rows={3} /></label>{formError && <p className="form-error" role="alert">{formError}</p>}<button className="button button--forest form-submit" disabled={submitting}>{submitting ? 'Sending...' : 'Send Enquiry'} <Send size={15} /></button><small>We’ll only use your details to respond to this enquiry.</small></form>}</Reveal>
          </div>
        </section>
      </main>

      <footer className="site-footer"><div className="container footer-top"><div><Logo light /><p>Taste Robusta, Feel Strength.</p></div><div className="footer-links"><span>Explore</span>{navItems.slice(0, 4).map(([label, href]) => <a key={href} href={href}>{label}</a>)}</div><div className="footer-contact"><span>Reach us</span><a href="tel:+918310595329">+91 83105 95329</a><a href="mailto:zayaanurrahman92@gmail.com">zayaanurrahman92@gmail.com</a><a href={WHATSAPP_URL} target="_blank" rel="noreferrer">WhatsApp us <ArrowUpRight size={13} /></a></div></div><div className="container footer-bottom"><span>© 2026 GreenPeak Coffee</span><span>Chikmagalur · India</span><span>Pure beans. Bolder flavors.</span></div></footer>
      <a className="floating-whatsapp" href={WHATSAPP_URL} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"><MessageCircle className="whatsapp-icon" size={17} /><span>Chat with us</span></a>
    </div>
  );
}

export default App;
